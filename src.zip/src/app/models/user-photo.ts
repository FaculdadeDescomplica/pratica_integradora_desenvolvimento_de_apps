export class UserPhoto {
  filepath: string = '';
  webviewPath: string = '';
}