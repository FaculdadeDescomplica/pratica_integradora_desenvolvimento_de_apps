export class Church {
    constructor(
        public id: string,
        public name: string,
        public lat: number,
        public lng: number) {
    }
}