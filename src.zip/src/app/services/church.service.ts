import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Church } from '../models/church';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ChurchService {
  BASE_URL: string = 'http://localhost:3000/';
  constructor(private http: HttpClient) { }

  /**  GET gas api */
  getChurchs(): Observable<Church[]> {    
    var url: string = this.BASE_URL + 'churchs';
    console.log(url)
    return this.http.get<Church[]>(url)
  }
 
}
