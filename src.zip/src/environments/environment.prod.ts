export const environment = {
  production: true,
  google_maps_api_key: 'AIzaSyBNffE-9XyZRbElAI7dNJLAEwCGuBn3woo'
};
